#!/bin/bash

rm gtest* *.o sample*
