#!/bin/bash

rm *.o *.a
